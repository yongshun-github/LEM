function [pred,gt] = LSM(pre,T,k,la1,la2,la3,in)
rand('seed',0)

Iter = 200;
 
test = in(:,:,pre-T:pre-1);

gt = in(:,:,pre);

R = test(:,:,1);
n = size(R,1);


A = 1+rand(k, k);
B = 1+rand(n, n);


%gt = gt.*100;

[U_mean, C, V_mean] = tri_nmf(gt,k,500);

for i = 1:T
    U(:,:,i) = U_mean;
    V(:,:,i) = V_mean;
end

for i = 1:50
    A = A.*((U(:,:,T)'*U_mean)./(U(:,:,T)'*U(:,:,T)*A + eps));
    B = B.*((V(:,:,T)'*V_mean)./(V(:,:,T)'*V(:,:,T)*B + eps));
end



L2 = getLoss(U,V,U_mean,V_mean,test,A,B,C,T,la1,la2,la3);

for i = 1:Iter
    for t = 1:T
        Ut = U(:,:,t);
        Vt = V(:,:,t);
        Gt = test(:,:,t);
        Dt = zeros(n,n);
        Wt = Gt + Gt';
        Wt(Wt>0) = 1;
        Wt(logical(eye(size(Wt))))=0;
        
        D_1 = sum(Wt,2);
        Dt(logical(eye(size(Dt)))) = D_1;
        
        
        if t == 1
            Ut = Ut.*((Gt*(C*Vt)' + la1.*(U(:,:,t)*A + U(:,:,t+1)*A') + la3.*Wt*Ut)./((Ut*C*Vt)*(C*Vt)' + la1.*(Ut+(Ut*A)*A')+ la3.*Dt*Ut + eps)); 
            Vt = Vt.*(((Ut*C)'*Gt + la1.*(V(:,:,t)*B + V(:,:,t+1)*B'))./((Ut*C)'*(Ut*C*Vt) + la1.*(Vt+(Vt*B)*B')+eps));

            
%                  U = U.*((G*(D*V)')./((U*D*V)*(D*V)'+eps));%tri-NMF 
%                  D = D.*((U'*G*V')./(U'*(U*D*V)*V'+eps));
%                  V = V.*((U*D)'*G./((U*D)'*(U*D*V)+eps));
            
            
            U(:,:,t) = Ut;
            V(:,:,t) = Vt;
        
        elseif t == T
            Ut = Ut.*((Gt*(C*Vt)' + la1.*(U(:,:,t-1)*A + U(:,:,t)*A')  + la2.*U_mean*A' + la3.*Wt*Ut)./((Ut*C*Vt)*(C*Vt)' + la1.*(Ut+(Ut*A)*A')+ la2.*(Ut*A)*A' + la3.*Dt*Ut + eps)); 
            Vt = Vt.*(((Ut*C)'*Gt + la1.*(V(:,:,t-1)*B + V(:,:,t)*B')+ la2.*V_mean*B' )./((Ut*C)'*(Ut*C*Vt) + la1.*(Vt+(Vt*B)*B')+ la2.*(Vt*B)*B' +eps));
            
            U(:,:,t) = Ut;
            V(:,:,t) = Vt;
        
        else
            Ut = Ut.*((Gt*(C*Vt)' + la1.*(U(:,:,t-1)*A + U(:,:,t+1)*A') + la3.*Wt*Ut)./((Ut*C*Vt)*(C*Vt)' + la1.*(Ut+(Ut*A)*A')+ la3.*Dt*Ut + eps)); 
            Vt = Vt.*(((Ut*C)'*Gt + la1.*(V(:,:,t-1)*B + V(:,:,t+1)*B'))./((Ut*C)'*(Ut*C*Vt) + la1.*(Vt+(Vt*B)*B')+eps));
            
            U(:,:,t) = Ut;
            V(:,:,t) = Vt;

        end
   
    end

    A1 = zeros(k);
    A2 = zeros(k);
    B1 = zeros(n);
    B2 = zeros(n);
    C1 = zeros(k);
    C2 = zeros(k);
    
    
    for j = 2:T
        A1 = A1 + U(:,:,j-1)'*U(:,:,j);
        A2 = A2 + U(:,:,j-1)'*U(:,:,j-1)*A;

    end    
    for j = 2:T
        B1 = B1 + V(:,:,j-1)'*V(:,:,j);
        B2 = B2 + V(:,:,j-1)'*V(:,:,j-1)*B;

    end     

    for q = 1:T
        
        C1 = C1 + U(:,:,q)'*test(:,:,q)*V(:,:,q)';
        C2 = C2 + U(:,:,q)'*(U(:,:,q)*C*V(:,:,q))*V(:,:,q)';
    end

    A = A.*((la1.*A1+la2.*(Ut'*U_mean))./(la1.*A2+la2.*(Ut'*(Ut*A))+eps));
    B = B.*((la1.*B1+la2.*(Vt'*V_mean))./(la1.*B2+la2.*(Vt'*(Vt*B))+eps));
    C = C.*(C1./(C2+eps));
    
    L1 = getLoss(U,V,U_mean,V_mean,test,A,B,C,T,la1,la2,la3);
    Q(i) = L1;
    L2 = L1;
    
    
    
end

plot(Q);

%D = D.*((U'*G*V')./(U'*(U*D*V)*V'+eps));
pred = Ut*A*C*(Vt*B);
%pred = Ht*B*(Ht)';
end