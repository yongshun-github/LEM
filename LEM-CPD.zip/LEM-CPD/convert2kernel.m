function K = convert2kernel(X,sigma)

    n = size(X,1);
    if size(X,2) == 1
        norms = X'.^2;
    else    
        norms = sum(X'.^2);
    end
    K = exp((-norms'*ones(1,n) - ones(n,1)*norms + 2*X*X')/(2*sigma^2));
end