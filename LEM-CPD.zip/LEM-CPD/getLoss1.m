function L = getLoss1(W,H,Wh1,Hh1,V,P,A,B,T,la1,la2)

    J1=0;
    J2=0;
    J3=0;


    for t = 1:T
        Wt = W(:,:,t);
        Ht = H(:,:,t);
        Vt = V(:,:,t);
        if size(P,3)==1
            Pt = P;
        else
            Pt = P(:,:,t);
        end
        J1 = J1+norm(Pt.*(Vt-Wt*Ht),'fro').^2 ;
        if t~=1        
            J2 = J2+la1.*(norm(Wt-W(:,:,t-1)*A,'fro').^2+norm(Ht-H(:,:,t-1)*B,'fro').^2);
        end
        
    end

    J3 = la2.*(norm(Wh1-W(:,:,T)*A,'fro').^2+norm(Hh1-H(:,:,T)*B,'fro').^2);

    L = 0.5*(J1+J2+J3);