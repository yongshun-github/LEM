load('AvgIn.mat')

choose = 1; %%%%%%   1: kernel station;   2:  weights;   3: kernel weather

if choose == 1

    sigma = 5;


    for i = 1:size(AvgIn,2)
        A = AvgIn{i};
        for j = 1:size(A,3)
            B = A(:,:,j);
            B(logical(eye(size(B)))) = 0;
            Kt = convert2kernel(zscore(B),sigma);
            KT(:,:,j) = Kt;
        end

        L_s{i} = KT;
    end
    
elseif choose == 2
    for i = 1:size(AvgIn,2)
        A = AvgIn{i};
        for j = 1:size(A,3)
            B = A(:,:,j);
            B = diag(B)';
            d = mapminmax(B,0,1)';
            D = 1- pdist2(d,d);
            W(:,:,j) = D;
        end

        W_s{i} = W;
    end
    
    
end