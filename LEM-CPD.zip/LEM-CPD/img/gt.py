import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import scipy.io as scio
plt.rcParams['font.sans-serif']=['SimHei']

dataFile = 'C:/Users/18778/Desktop/11/gt.mat'
data = scio.loadmat(dataFile)
print(data)
print(data['gt30'])
G = nx.Graph()
Matrix=data['gt30']
for i in range(len(Matrix)):
    for j in range(len(Matrix)):
        if Matrix[i][j]!=0:
            G.add_edge(i, j)



pos = [(0.2,4.7),(0.6,4.4),(1,4),(1.5,3),(1,2.5),(1,2),(1,1),(1.5,1),(2.5,1),(3,1),(4,1),(4.5,1),(4,0.5),(4,2),(3.6,2),(3,2),(2,2),(1.5,2),(2.2,2.5),(2.5,3),(3,3),(2.5,3.5),(2.5,4),(3.5,4.0),(4,2.5),(4,3.5),(4,4),(3,4.4),(2.5,4.6),(2.7,4.8)]#悉尼
area = np.pi * 4 ** 2.5
plt.scatter(3,1, s=area, c='orange')
plt.scatter(1,2.5, s=area, c='orange')
nx.draw_networkx_nodes(G, pos, node_size=100,node_color='orange',label='station')

nx.draw_networkx_edges(G, pos,edge_color='#2794FF',label=' crowd flow')


plt.legend(loc='upper right',fontsize=15,edgecolor='black',facecolor='none')

ax = plt.gca()

font2 = {'weight':'normal','size': 20,}
ax.set_xlabel('X',font2)
ax.set_ylabel('Y',font2)

plt.show()

