% A = result1(:,:,8);
% 
% gplot(A,Coordinates);


X = (1:69);
%Y = (2+ rand(1,151)*2)./10;

plot(X,Y)
showplottool('propertyeditor')