
function [U,D,V] = tri_nmf(G, K, MAXITER)
%Euclidean distance
 F = size(G,1);
 T = size(G,2);

  
rand('seed',0)

U = 1+rand(F, K);

D = 1+rand(K, K);

V = 1+rand(K, T);

  
    for i=1:MAXITER


     U = U.*((G*(D*V)')./((U*D*V)*(D*V)'+eps));%tri-NMF 
     D = D.*((U'*G*V')./(U'*(U*D*V)*V'+eps));
     V = V.*((U*D)'*G./((U*D)'*(U*D*V)+eps));
     
     L = loss(G,U,D,V);
     Q(i) = L;
    end
%plot(Q);
end

function L = loss(G,U,D,V)

    L = norm((G-U*D*V),'fro').^2;

end