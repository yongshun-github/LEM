
load('IN_Test.mat');
load('IN_TIME_STD.mat');
load('AvgIn.mat');


inT = IN_TIME_STD;
Avg = AvgIn;
input = IN_Test;

la1 = 2^6;
la2 = 2^13;

timestamp = 8;
WindowT1 = 6;

k = 70; % latent dimension

[P1,gt] = LEM(timestamp,WindowT1,k,la1,la2,Avg,input,inT);
P1(P1<0.3)=1;

