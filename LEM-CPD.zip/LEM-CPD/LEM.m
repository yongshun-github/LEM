function [gt_ba,gt] = LEM(pre,T,k,la1,la2,Avg,in,inT)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% pre: the time span to predict
% T: window size
% k: dimention
% la1,la2,la3: lambda1,2,3
% Avg: Average historical data
% in: the data of prediction and groudtruth
% inT: during time,95%confidence


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


rand('seed',0)

if nargin > 7
    
    if pre>64
        for u = pre-T-2:size(Avg,3)
            U1 = Avg(:,:,u)';
            Avg(:,:,u)=U1;
            U2 = in(:,:,u)';
            in(:,:,u) = U2;
            U3 = inT(:,:,u)';
            inT(:,:,u) = U3; 
        end

    end
else
    if pre>64
        for u = pre-T-2:size(Avg,3)
            U1 = Avg(:,:,u)';
            Avg(:,:,u)=U1;
            U2 = in(:,:,u)';
            in(:,:,u) = U2;
        end

    end
end


Err = 2^-6;
Iter = 250; %iteration

k2 = 30;



in2 = Avg;

%%%%%%%%%% make sure diag(X)=0%%%%%%%%
for i = 1:1:size(in,3)
    ZZ = in(:,:,i);
    ZZ(logical(speye(size(ZZ)))) = 0;
    in(:,:,i) = ZZ;  
    Z2 = in2(:,:,i);
    Z2(logical(speye(size(Z2)))) = 0;
    in2(:,:,i) = Z2;

    
end

%%%%%%%% P is the weight matrix of initialization %%%%%%%%
P = ones(size(in,1),size(in,1));
 P(logical(speye(size(P)))) = 0;
%%%%%%%% P1 is the weight matrix of prediction %%%%%%%%

if nargin > 7
        it = inT(:,:,pre-T:pre-1);% the used data of travel duration
        for i1 = 1:T
            dur = it(:,:,i1) - (T-i1)*900;
            dur(dur<=0) = 1;
            dur(dur~=1) = 0;
            P1(:,:,i1) = dur;
        end

         for i2 = 1:T
             PP = P1(:,:,i2);
             PP(logical(speye(size(PP)))) = 0;
             P1(:,:,i2) = PP;
         end
else
    P1 =P;
end
 
 V = in(:,:,pre-T:pre-1);


 if pre>64
     gt = in(:,:,pre)';
 else
     gt = in(:,:,pre);
    
 end
 
C = V(:,:,1);
n = size(C,1);

A = 10+rand(k, k);

B = 10+rand(n, n);


    



[Whh,Hhh] = nmf(in2(:,:,pre),k,500);

for i = 1:T+1
    WW(:,:,i) = Whh;

    HH(:,:,i)= Hhh;
end

testh = in2(:,:,pre-T:pre);


    


%%%%%%%% initialize Wt,Ht,A and B, get the history value of Wt+1,Ht+1%%%%%%%%
for i = 1:150

        for t = 1:T+1
        WWt = WW(:,:,t);
        HHt = HH(:,:,t);
        VVt = testh(:,:,t);
        
            
            if t == 1
            WWtE = WWt.*((P.*VVt*HHt'+la1.*(WW(:,:,t)*A+WW(:,:,t+1)*A'))./(P.*(WWt*HHt)*HHt'+la1.*(WWt+(WWt*A)*A')+eps));
            
            WWt = k2.*WWtE./norm(WWtE,'fro');
            
            HHt = HHt.*((WWt'*(P.*VVt)+la1.*(HH(:,:,t)*B+HH(:,:,t+1)*B'))./(WWt'*(P.*(WWt*HHt))+la1.*(HHt+(HHt*B)*B')+eps));
            
            

            
            WW(:,:,t) = WWt;
            HH(:,:,t) = HHt;
            

            elseif t == T+1
            WWtE = WWt.*((P.*VVt*HHt'+la1.*(WW(:,:,t-1)*A+WW(:,:,t)*A'))./(P.*(WWt*HHt)*HHt'+la1.*(WWt+(WWt*A)*A')+eps));
            
            WWt = k2.*WWtE./norm(WWtE,'fro');
            
            
            HHt = HHt.*((WWt'*(P.*VVt)+la1.*(HH(:,:,t-1)*B+HH(:,:,t)*B'))./(WWt'*(P.*(WWt*HHt))+la1.*(HHt+(HHt*B)*B')+eps));
            
            
            

            
            
            WW(:,:,t) = WWt;
            HH(:,:,t) = HHt;

            else
            WWtE = WWt.*((P.*VVt*HHt'+la1.*(WW(:,:,t-1)*A+WW(:,:,t+1)*A'))./(P.*(WWt*HHt)*HHt'+la1.*(WWt+(WWt*A)*A')+eps));
            
            WWt = k2.*WWtE./norm(WWtE,'fro');
            
            
            HHt = HHt.*(WWt'*(P.*VVt)+la1.*(HH(:,:,t-1)*B+HH(:,:,t+1)*B'))./(WWt'*(P.*(WWt*HHt))+la1.*(HHt+(HHt*B)*B')+eps);
            
            

                       
            WW(:,:,t) = WWt;
            HH(:,:,t) = HHt;
           % Y2= (P.*(WWt*HHt)*HHt'+la1.*(WWt+(WWt*A)*A')+la3.*WWt)-(P.*VVt*HHt'+la1.*(WW(:,:,t-1)*A+WW(:,:,t+1)*A'));
                      
            end
            


        end
            A1 = zeros(k);
            A2 = zeros(k);
            B1 = zeros(n);
            B2 = zeros(n);
%             A1 = WW(:,:,1)'*WW(:,:,1);
%             A2 = WW(:,:,1)'*(WW(:,:,1)*A);
%             B1 =  HH(:,:,1)'*HH(:,:,1);
%             B2 = HH(:,:,1)'*(HH(:,:,1)*B);
   
        for j = 2:T+1
            A1 = A1 + WW(:,:,j-1)'*WW(:,:,j);
            A2 = A2 + WW(:,:,j-1)'*(WW(:,:,j-1)*A);

            B1 = B1 + HH(:,:,j-1)'*HH(:,:,j);
            B2 = B2 + HH(:,:,j-1)'*(HH(:,:,j-1)*B);
        end
        
        
        
            A = A.*((la1.*A1)./(la1.*A2+eps));
            B = B.*((la1.*B1)./(la1.*B2+eps));
   
    

end



Wh1 = WWt;
Hh1 = HHt;

% 
for i = 1:T
    W(:,:,i) = Wh1;

    H(:,:,i)= Hh1;
end


    L2 = getLoss1(W,H,Wh1,Hh1,V,P1,A,B,T,la1,la2);


%%%%%%%%%%%% prediction %%%%%%%%%%%%%%
for i = 1:Iter
    for t = 1:T
        Wt = W(:,:,t);
        Ht = H(:,:,t);
        Vt = V(:,:,t);
        if nargin > 7 
            Pt = P1(:,:,t);
        else
            Pt = P;
        end
        if t == 1
            WtE = Wt.*((Pt.*Vt*Ht'+la1.*(W(:,:,t)*A+W(:,:,t+1)*A'))./(Pt.*(Wt*Ht)*Ht'+la1.*(Wt+(Wt*A)*A')+eps));
            
            Wt = k2.*WtE./norm(WtE,'fro');
            
            Ht = Ht.*((Wt'*(Pt.*Vt)+la1.*(H(:,:,t)*B+H(:,:,t+1)*B'))./(Wt'*(Pt.*(Wt*Ht))+la1.*(Ht+(Ht*B)*B')+eps));

            
            


            W(:,:,t) = Wt;
            H(:,:,t) = Ht;

            
        elseif t == T



            WtE = Wt.*((Pt.*Vt*Ht'+la1.*(W(:,:,t-1)*A+W(:,:,t)*A')+la2.*Wh1*A')./(Pt.*(Wt*Ht)*Ht'+la1.*(Wt+(Wt*A)*A')+la2.*(Wt*A)*A'+eps));
            
            Wt = k2.*WtE./norm(WtE,'fro');
            
            Ht = Ht.*((Wt'*(Pt.*Vt)+la1.*(H(:,:,t-1)*B+H(:,:,t)*B')+la2.*Hh1*B')./(Wt'*(Pt.*(Wt*Ht))+la1.*(Ht+(Ht*B)*B')+la2.*(Ht*B)*B'+eps));
            
            
            

            
            
            W(:,:,t) = Wt;
            H(:,:,t) = Ht;
            
            
        else
            WtE = Wt.*((Pt.*Vt*Ht'+la1.*(W(:,:,t-1)*A+W(:,:,t+1)*A'))./(Pt.*(Wt*Ht)*Ht'+la1.*(Wt+(Wt*A)*A')+eps));
            
            Wt = k2.*WtE./norm(WtE,'fro');
            
            Ht = Ht.*((Wt'*(Pt.*Vt)+la1.*(H(:,:,t-1)*B+H(:,:,t+1)*B'))./(Wt'*(Pt.*(Wt*Ht))+la1.*(Ht+(Ht*B)*B')+eps));
            
            
            

            
            
            W(:,:,t) = Wt;
            H(:,:,t) = Ht;
            
           

        end
   
    end
            A1 = zeros(k);
            A2 = zeros(k);
            B1 = zeros(n);
            B2 = zeros(n);
   
    for j = 2:T
        A1 = A1 + W(:,:,j-1)'*W(:,:,j);
        A2 = A2 + W(:,:,j-1)'*(W(:,:,j-1)*A);

        B1 = B1 + H(:,:,j-1)'*H(:,:,j);
        B2 = B2 + H(:,:,j-1)'*(H(:,:,j-1)*B);
    end    
   
    A = A.*((la1.*A1+la2.*(Wt'*Wh1))./(la1.*A2+la2.*(Wt'*(Wt*A))+eps));
    B = B.*((la1.*B1+la2.*(Ht'*Hh1))./(la1.*B2+la2.*(Ht'*(Ht*B))+eps));
    

    
    L1 = getLoss1(W,H,Wh1,Hh1,V,P1,A,B,T,la1,la2);
    L=abs(L2-L1);


   Q(i) = L1;
   if i>500
    if L<Err || L2>L1
        break;
    end
   end
    L2 = L1;
end
%plot(Q);



gt_ba = Wt*A*(Ht*B);

if pre>64
    gt_ba = gt_ba';
end

%[c,D,D1,D2,D3] = getMAE(gt_ba,gt,pre);


end
















